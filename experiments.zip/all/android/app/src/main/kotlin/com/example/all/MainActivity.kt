package com.example.all

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
